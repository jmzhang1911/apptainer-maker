

set -ex



yq --help
exit 0
