library(testthat)
library(cellassign)

test_check("cellassign")
