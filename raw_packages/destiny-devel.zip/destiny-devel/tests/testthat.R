library(testthat)
library(destiny)

test_check('destiny')
